const { name } = require("ejs");
const mongoose = require("mongoose");

const uri =
  "mongodb+srv://obehi:blessing@cluster0.in1ka.mongodb.net/KioskApp?retryWrites=true&w=majority&appName=Cluster0";

mongoose
  .connect(uri)
  .then(() => {
    console.log("###Connected to Mongo DB Successfully");
  })
  .catch((error) => {
    console.log(`Connection Failed due to error below. \n${error}`);
  });

const userSchema = mongoose.Schema({
  firstname: { type: String, default: "default" },
  lastname: { type: String, default: "default" },
  licenseno: { type: String, default: "default" },
  dob: { type: Date, default: Date.now },
  age: { type: Number, default: 0 },
  appointmentId: { type: mongoose.Schema.Types.ObjectId, ref: "Appointment" },
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  userType: {
    type: String,
    enum: ["Driver", "Examiner", "Admin"],
    required: true,
  },
  car_details: {
    make: { type: String, default: "" },
    model: { type: String, default: "" },
    year: { type: Number, default: 0 },
    platno: { type: String, default: "" },
  },
  TestType: { type: String, enum: ["G", "G2"], required: false },
  comment: { type: String, default: "" },
  passFailStatus: { type: Boolean, default: null },
});

const userModel = mongoose.model("User", userSchema);

module.exports = userModel;
