function checkPasswordMatch() {
  const password = document.getElementById("signupPassword").value;
  const confirmPassword = document.getElementById("confirmPassword").value;
  const errorMessage = document.getElementById("error-message");
  const submitBtn = document.getElementById("submitBtn");

  if (password !== confirmPassword) {
    errorMessage.textContent = "Passwords do not match.";
    submitBtn.disabled = true;
  } else {
    errorMessage.textContent = "";
    submitBtn.disabled = false;
  }
}
