const controller = require("../controllers/controller.js");

const express = require("express");

const router = express.Router();

router.get("/hom", controller.g2_get);

router.get("/signup", controller.signup_get);

router.post("/signup", controller.signup_post);

router.get("/login", controller.login_get);

router.post("/login", controller.login_post);

router.get("/dashboard", controller.dashboard_get);

module.exports = router;
