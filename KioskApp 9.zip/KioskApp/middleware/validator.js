const isValidUser = (req, res, next) => {
  // Check if the user is logged in
  if (req.session.isValid) {
    return next();
  } else {
    req.session.msg = "Please Login/Signup First to access the Dashboard page!";
    console.log("User not authenticated. Redirecting to login.");
    return res.redirect("/Login");
  }
};

const isDriver = (req, res, next) => {
  // Check if the user is logged in and is a Driver
  if (req.session.isValid && req.session.userType === "Driver") {
    return next();
  } else {
    req.session.msg = "Access denied. Drivers only!";
    console.log("User is not a Driver. Redirecting to login.");
    return res.redirect("/Login");
  }
};

const isAdmin = (req, res, next) => {
  // Check if the user is logged in and is an Admin
  if (req.session.userType === "Admin") {
    return next();
  } else {
    req.session.msg = "Access denied. Admins only!";
    console.log("User is not an Admin. Redirecting to login.");
    return res.redirect("/Login");
  }
};

const isExaminer = (req, res, next) => {
  if (req.session.userType === "Examiner") {
    return next(); // Allow access if user is an Examiner
  } else {
    req.session.msg = "Access denied. Examiners only!";
    console.log("User is not an Examiner. Redirecting to login.");
    return res.redirect("/Login");
  }
};

module.exports = { isValidUser, isDriver, isAdmin, isExaminer };

// module.exports = isValidUser;
