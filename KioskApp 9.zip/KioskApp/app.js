console.log("****Welcome****");

const express = require("express");

const session = require("express-session");

//to handle file paths
// const path = require("path");

const {
  isValidUser,
  isDriver,
  isAdmin,
  isExaminer,
} = require("./middleware/validator.js");

const app = express();

app.use(
  session({
    secret: "Any hidden key ",
    resave: false,
    saveUninitialized: false,
  })
);

const router = require("./routes/routes.js");

const port = 5010;

const UserModel = require("./models/userModel.js");
const Appointment = require("./models/appointmentModel.js");

const { model } = require("mongoose");

app.listen(port, () => {
  console.log(`App is listening at port ${port}!!!`);
});

app.use(express.static("public"));

app.set("view-engine", "ejs");

app.use(express.urlencoded({ extended: true }));

app.get("/G2", async (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/Login");
  }

  try {
    const user = await UserModel.findById(req.session.userId);
    if (user) {
      res.render("g2_page.ejs", {
        userId: req.session.userId,
        userType: req.session.userType,
        user,
      });
    } else {
      res.status(404).send("<h2>User not found.</h2>");
    }
  } catch (err) {
    console.error(err);
    res.status(500).send("<h2>Error retrieving user data.</h2>");
  }
});

// New /G2 POST route
app.post("/G2", async (req, res) => {
  try {
    const data = req.body;
    const userToUpdate = await UserModel.findById(req.session.userId);

    if (!userToUpdate) {
      return res
        .status(404)
        .send(
          `<h2>User not found. Please log in again.</h2><a href="/Login">Back to Login</a>`
        );
    }

    // Update user basic info if any field is missing or empty
    userToUpdate.firstname = data.fname
      ? data.fname.trim()
      : userToUpdate.firstname;
    userToUpdate.lastname = data.lname
      ? data.lname.trim()
      : userToUpdate.lastname;
    userToUpdate.age = data.age !== undefined ? data.age : userToUpdate.age;
    userToUpdate.licenseno = data.licenseno
      ? data.licenseno.trim()
      : userToUpdate.licenseno;
    userToUpdate.dob = data.dob ? data.dob.trim() : userToUpdate.dob;

    // Set TestType to "G2" since the form is from G2_page
    userToUpdate.TestType = "G2";

    // Update car details if provided
    if (data.make || data.model || data.year || data.platno) {
      userToUpdate.car_details = {
        make: data.make || userToUpdate.car_details.make,
        model: data.model || userToUpdate.car_details.model,
        year:
          data.year !== undefined ? data.year : userToUpdate.car_details.year,
        platno: data.platno || userToUpdate.car_details.platno,
      };
    }

    await userToUpdate.save(); // Save the updated user
    res.redirect("/G2");
  } catch (err) {
    console.log(`User Not Updated due to the error: ${err}`);
    res
      .status(500)
      .send("<h2>Error saving user information. Please try again later.</h2>");
  }
});

app.get("/G", async (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  const userId = req.session.userId;
  const userType = req.session.userType;

  const user = await UserModel.findById(userId);
  if (!user) {
    return res
      .status(404)
      .send(
        `<h2>User not found. Please log in again.</h2><a href="/Login">Back to Login</a>`
      );
  }

  // Check if user data is default
  if (
    user.firstname === "default" ||
    user.lastname === "default" ||
    user.age === "default"
  ) {
    return res.redirect("/G2");
  }

  res.render("g_page.ejs", { userId, userType, user });
});

app.post("/G", async (req, res) => {
  if (!req.session.userId || req.session.userType !== "Driver") {
    return res
      .status(403)
      .send(
        `<h2>Access denied. Drivers only.</h2><a href="/Login">Back to Login</a>`
      );
  }

  try {
    const user = await UserModel.findById(req.session.userId);
    if (!user) {
      return res
        .status(404)
        .send(
          `<h2>User not found. Please log in again.</h2><a href="/Login">Back to Login</a>`
        );
    }

    // Set TestType to "G" since the form is from G_page
    user.TestType = "G";

    user.car_details.make = req.body.make;
    user.car_details.model = req.body.model;
    user.car_details.year = req.body.year;
    user.car_details.platno = req.body.platno;

    await user.save();

    res.redirect("/G");
  } catch (err) {
    console.error(`Error updating user data: ${err}`);
    res
      .status(500)
      .send(
        "<h2>Error updating user information. Please try again later.</h2>"
      );
  }
});

app.get("/edit/:licenseno", async (req, res) => {
  try {
    const { licenseno } = req.params;

    const user_from_db = await user.findOne({ licenseno });

    if (!user_from_db) {
      return res.status(404).send("No User Found.");
    }

    res.render("edit.ejs", { user: user_from_db });
  } catch (err) {
    console.log(err);
    res.send(err);
  }
});
app.post("/update/:licenseno", async (req, res) => {
  try {
    const { make, model, year } = req.body;
    const { licenseno } = req.params;

    // Find the user by licenseno and update the car details
    const updatedUser = await user.findOneAndUpdate(
      { licenseno: licenseno },
      {
        $set: {
          "car_details.make": make,
          "car_details.model": model,
          "car_details.year": year,
        },
      },
      { new: true }
    );

    if (!updatedUser) {
      return res.status(404).send("User not found");
    }

    // Render the update success page
    res.render("updatesuccess.ejs");
  } catch (err) {
    console.log(`Error updating user: ${err}`);
    res.status(500).send(err);
  }
});

app.get("/Login", (req, res) => {
  const userId = req.session.userId;
  const userType = req.session.userType;

  res.render("login.ejs", { userId, userType });
});

// app.get("/dashboard", (req, res) => {
//   const userId = req.session.userId;
//   const userType = req.session.userType || null;

//   res.render("dashboard.ejs", { userId, userType });
// });

app.get("/dashboard", async (req, res) => {
  if (!req.session.userId) {
    return res
      .status(403)
      .send(`<h2>Access denied. You need to be logged in.</h2>`);
  }

  try {
    let driver = null;

    // Only fetch driver data if the user is a Driver
    if (req.session.userType === "Driver") {
      driver = await UserModel.findOne({
        _id: req.session.userId,
        userType: "Driver",
      }).lean();
    }

    // Render the dashboard, pass the driver data if available
    res.render("dashboard.ejs", {
      driver, // Pass driver data (if available)
      userId: req.session.userId,
      userType: req.session.userType,
    });
  } catch (err) {
    console.error(`Error fetching driver information: ${err}`);
    res
      .status(500)
      .send("<h2>Error fetching information. Please try again later.</h2>");
  }
});

// Logout route
app.get("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.redirect("/dashboard");
    }
    res.redirect("/login");
  });
});

app.get("/success", (req, res) => {
  const userId = req.session.userId || null;
  res.render("success", { userId });
});

// Admin-only route
app.get("/appointment", isAdmin, async (req, res) => {
  const userId = req.session.userId;
  const userType = req.session.userType;

  // Fetch all appointments sorted by date and time (most recent first)
  const appointments = await Appointment.find({}).sort({ date: -1, time: -1 }); // Sort by date descending, then by time descending

  res.render("appointment.ejs", {
    userId: userId,
    userType: userType,
    appointments: appointments,
  });
});

app.post("/appointment", isAdmin, async (req, res) => {
  const { date, hour, minute, ampm } = req.body;
  const time = `${hour}:${minute} ${ampm}`;

  // Ensure the date is in the future
  const today = new Date().toISOString().split("T")[0];
  if (date < today) {
    return res.status(400)
      .send(`<h1>You can only add future appointment dates.</h1>
      <a href="/Appointment">Go back to Appointment</a>`);
  }

  try {
    const existingAppointment = await Appointment.findOne({ date, time });
    if (existingAppointment) {
      return res
        .status(400)
        .send(
          `<h1>This appointment slot already exists.</h1><a href="/Appointment">Go back to Appointment</a>`
        );
    }

    const newAppointment = new Appointment({
      date,
      time,
      isTimeSlotAvailable: true,
    });
    await newAppointment.save();

    res.status(200).send(
      `<h1>Appointment slot created successfully.</h1>
       <a href="/Appointment">Go back to Appointment</a>`
    );
  } catch (err) {
    console.error("Error creating appointment slot:", err);
    res.status(500).send("Error saving appointment slot.");
  }
});

app.get("/check-appointment/:date", async (req, res) => {
  const userId = req.session.userId;
  const selectedDate = req.params.date;

  try {
    const user = await UserModel.findById(userId);
    const appointment = user.appointmentId;

    if (appointment) {
      const existingAppointment = await Appointment.findById(appointment);

      // Ensure existingAppointment.date is a Date object
      const existingDate = new Date(existingAppointment.date);
      const selectedDateObj = new Date(selectedDate);

      // Normalize to midnight to only compare the date part
      existingDate.setHours(0, 0, 0, 0);
      selectedDateObj.setHours(0, 0, 0, 0);

      // Check if the user already has an appointment on the selected date
      if (existingDate.getTime() === selectedDateObj.getTime()) {
        return res.json({
          hasAppointment: true,
          time: existingAppointment.time, // Return the appointment time
        });
      }
    }

    return res.json({ hasAppointment: false }); // No appointment for the selected date
  } catch (err) {
    console.error("Error checking appointment:", err);
    res.status(500).send("Error checking appointment.");
  }
});

app.get("/get-user-appointment", async (req, res) => {
  const userId = req.session.userId;

  try {
    const user = await UserModel.findById(userId);
    const appointment = user.appointmentId;

    if (appointment) {
      const existingAppointment = await Appointment.findById(appointment);
      const appointmentDate = new Date(existingAppointment.date);
      const appointmentTime = existingAppointment.time;

      return res.json({
        hasAppointment: true,
        date: appointmentDate.toISOString().split("T")[0], // Returning date in yyyy-mm-dd format
        time: appointmentTime,
      });
    }

    return res.json({ hasAppointment: false });
  } catch (err) {
    console.error("Error fetching user appointment:", err);
    res.status(500).send("Error fetching appointment.");
  }
});

// app.get("/check-appointment/:date", async (req, res) => {
//   const userId = req.session.userId;
//   const selectedDate = req.params.date;

//   try {
//     const user = await UserModel.findById(userId);
//     const appointment = user.appointmentId;

//     if (appointment) {
//       const existingAppointment = await Appointment.findById(appointment);
//       if (existingAppointment && existingAppointment.date === selectedDate) {
//         return res.json({
//           time: existingAppointment.time,
//         });
//       }
//     }
//     return res.json(null); // No existing appointment
//   } catch (err) {
//     console.error("Error checking appointment:", err);
//     res.status(500).send("Error checking appointment.");
//   }
// });

app.get("/available-slots/:date", async (req, res) => {
  const { date } = req.params;

  try {
    const availableSlots = await Appointment.find({
      date: date,
      isTimeSlotAvailable: true,
    });

    res.json(availableSlots); // Return available slots as JSON
  } catch (err) {
    console.error("Error fetching available slots:", err);
    res.status(500).send("Error fetching slots.");
  }
});

// Booking route

app.post("/book-appointment/:id", async (req, res) => {
  const userId = req.session.userId;
  const appointmentId = req.params.id;

  console.log(
    `Booking attempt for userId: ${userId} and appointmentId: ${appointmentId}`
  );

  // Ensure the user ID is in the session
  if (!userId) {
    console.error("User ID is not found in the session.");
    return res.status(400).send("User not found. Please log in.");
  }

  const user = await UserModel.findById(userId);
  if (!user) {
    console.error(`User with ID ${userId} not found`);
    return res.status(404).send("User not found.");
  }

  // Check if the user already has an appointment booked
  if (user.appointmentId) {
    const existingAppointment = await Appointment.findById(user.appointmentId);
    if (existingAppointment) {
      if (new Date(existingAppointment.date) >= new Date()) {
        console.log(
          `User already has an appointment: ${existingAppointment.date}`
        );
        return res
          .status(400)
          .send(
            `You already have an appointment on ${existingAppointment.date}`
          );
      }
    }
  }

  // Check if the appointment exists and is available
  const appointment = await Appointment.findById(appointmentId);
  if (!appointment) {
    console.error(`Appointment with ID ${appointmentId} not found`);
    return res.status(404).send("Appointment not found.");
  }

  // Ensure the appointment date is in the future
  const today = new Date().toISOString().split("T")[0];
  if (new Date(appointment.date).toISOString().split("T")[0] < today) {
    console.log("Attempt to book an appointment in the past.");
    return res.status(400).send("You cannot book appointments in the past.");
  }

  if (!appointment.isTimeSlotAvailable) {
    console.log("The time slot is no longer available.");
    return res.status(400).send("This time slot is no longer available.");
  }

  // Proceed with booking the appointment
  user.appointmentId = appointmentId;
  await user.save();

  appointment.isTimeSlotAvailable = false; // Mark the slot as unavailable
  await appointment.save();

  console.log(
    `Appointment with ID ${appointmentId} booked successfully for userId: ${userId}`
  );
  res.status(200).send("Appointment booked successfully.");
});

// app.post("/book-appointment/:id", async (req, res) => {
//   const userId = req.session.userId;
//   const appointmentId = req.params.id;

//   console.log(
//     `Booking attempt for userId: ${userId} and appointmentId: ${appointmentId}`
//   );

//   // Ensure the user ID is in the session
//   if (!userId) {
//     console.error("User ID is not found in the session.");
//     return res.status(400).send("User not found. Please log in.");
//   }

//   // Fetch the user from the database
//   const user = await UserModel.findById(userId);
//   if (!user) {
//     console.error(`User with ID ${userId} not found`);
//     return res.status(404).send("User not found.");
//   }

//   // Check if the user already has an appointment booked
//   if (user.appointmentId) {
//     const existingAppointment = await Appointment.findById(user.appointmentId);
//     if (existingAppointment) {
//       // If the existing appointment is a future one, reject the new booking
//       if (new Date(existingAppointment.date) >= new Date()) {
//         console.log(
//           `User already has an appointment with ID ${user.appointmentId}`
//         );
//         return res
//           .status(400)
//           .send(
//             `You already have an appointment on ${new Date(
//               existingAppointment.date
//             ).toLocaleString()} at ${existingAppointment.time}.`
//           );
//       }
//     }
//   }

//   // Check if the new appointment exists and is available
//   const appointment = await Appointment.findById(appointmentId);
//   if (!appointment) {
//     console.error(`Appointment with ID ${appointmentId} not found`);
//     return res.status(404).send("Appointment not found.");
//   }

//   if (!appointment.isTimeSlotAvailable) {
//     console.log("The time slot is no longer available.");
//     return res.status(400).send("This time slot is no longer available.");
//   }

//   // Ensure the appointment date is in the future
//   const today = new Date().toISOString().split("T")[0];
//   if (new Date(appointment.date).toISOString().split("T")[0] < today) {
//     console.log("Attempt to book an appointment in the past.");
//     return res.status(400).send("You cannot book appointments in the past.");
//   }

//   // Proceed to book the appointment
//   user.appointmentId = appointmentId;
//   await user.save();

//   appointment.isTimeSlotAvailable = false;
//   await appointment.save();

//   console.log(
//     `Appointment with ID ${appointmentId} booked successfully for userId: ${userId}`
//   );
//   res.status(200).send("Appointment booked successfully.");
// });

app.get("/check-appointment", async (req, res) => {
  const userId = req.session.userId; // Assuming the user is authenticated
  const appointment = await Appointment.findOne({ userId });

  if (appointment) {
    return res.json({ date: appointment.date, time: appointment.time });
  }

  res.json(null);
});

app.post("/book-appointment/:slotId", async (req, res) => {
  const userId = req.user._id; // Assuming you have user authentication
  const slotId = req.params.slotId;

  // Fetch the user's existing appointment
  const existingAppointment = await Appointment.findOne({ userId });

  if (existingAppointment) {
    return res.status(400).send("You already have an appointment booked.");
  }

  // If no existing appointment, proceed with booking the new appointment
  const slot = await Slot.findById(slotId);

  if (!slot || !slot.isTimeSlotAvailable) {
    return res.status(400).send("Selected time slot is unavailable.");
  }

  const newAppointment = new Appointment({
    userId,
    slotId,
    date: slot.date,
    time: slot.time,
  });

  await newAppointment.save();

  // Mark the slot as unavailable
  slot.isTimeSlotAvailable = false;
  await slot.save();

  res.status(200).send("Appointment booked successfully.");
});

//Examiner
app.get("/examiner", async (req, res) => {
  if (!req.session.userId || req.session.userType !== "Examiner") {
    return res
      .status(403)
      .send(
        `<h2>Access denied. Examiner only.</h2><a href="/Login">Back to Login</a>`
      );
  }

  const testType = req.query.testType || ""; // Get testType from query parameter
  let filter = { userType: "Driver", passFailStatus: null }; // Exclude drivers with Pass/Fail status

  // If testType is provided, filter by TestType
  if (testType) {
    filter.TestType = testType;
  }

  try {
    const users = await UserModel.find(filter); // Fetch filtered drivers
    res.render("examiner.ejs", {
      users, // Pass filtered users to the view
      userId: req.session.userId,
      userType: req.session.userType,
    });
  } catch (err) {
    console.error(`Error fetching drivers: ${err}`);
    res
      .status(500)
      .send(
        "<h2>Error fetching driver information. Please try again later.</h2>"
      );
  }
});

app.post("/examiner/submit-test", async (req, res) => {
  const { driverId, comment, passFail } = req.body;

  try {
    // Find the driver and update their Pass/Fail status and comment
    const driver = await UserModel.findById(driverId);

    if (driver) {
      driver.passFailStatus = passFail === "true"; // Convert to boolean
      driver.comment = comment;
      await driver.save();

      // Redirect examiner back to the examiner page after submission
      res.redirect("/examiner");
    } else {
      res.status(404).send("<h2>Driver not found.</h2>");
    }
  } catch (err) {
    console.error(`Error updating driver status: ${err}`);
    res
      .status(500)
      .send("<h2>Error submitting test results. Please try again later.</h2>");
  }
});

//ADMIN
app.get("/admin", async (req, res) => {
  if (!req.session.userId || req.session.userType !== "Admin") {
    return res
      .status(403)
      .send(
        `<h2>Access denied. Admin only.</h2><a href="/Login">Sign Up /Log In as Admin</a>`
      );
  }

  const passFailFilter = req.query.passFailFilter; // Get the pass/fail filter from the query parameter
  let filter = { userType: "Driver" }; // Default to all drivers

  // If passFailFilter is provided, filter by passFailStatus
  if (passFailFilter === "true") {
    filter.passFailStatus = true; // Only show Pass candidates
  } else if (passFailFilter === "false") {
    filter.passFailStatus = false; // Only show Fail candidates
  }

  try {
    const users = await UserModel.find(filter); // Fetch filtered drivers based on the pass/fail status
    res.render("admin.ejs", {
      users, // Pass the filtered users to the view
      userId: req.session.userId,
      userType: req.session.userType,
    });
  } catch (err) {
    console.error(`Error fetching drivers: ${err}`);
    res
      .status(500)
      .send(
        "<h2>Error fetching driver information. Please try again later.</h2>"
      );
  }
});

app.use("/", router);
