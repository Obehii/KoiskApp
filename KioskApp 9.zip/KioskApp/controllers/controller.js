const bcrypt = require("bcrypt");
const User = require("../models/userModel.js");

class Controller {
  static dashboard_get = (req, res) => {
    res.render("dashboard.ejs");
  };
  static login_post = async (req, res) => {
    const { uname, upass } = req.body;

    try {
      const user = await User.findOne({ username: uname });
      if (!user) {
        return res
          .status(404)
          .send(
            `<h2>User not found. Please signup.</h2><a href="/Login">Go back to Signup</a>`
          );
      }

      const isMatch = await bcrypt.compare(upass, user.password);
      if (!isMatch) {
        return res
          .status(401)
          .send(`<h2>Incorrect password.</h2><a href="/Login">Try Again</a>`);
      }

      // Set session data
      req.session.userId = user._id;
      req.session.userType = user.userType;

      // Log session data for debugging
      console.log("Session Data:", req.session);

      // Respond with success message (instead of redirect)
      res.redirect("/dashboard");
    } catch (err) {
      console.error("Login error:", err);
      res
        .status(500)
        .send(
          `<h2>Login failed. Please try again later.</h2><a href="/Login">Back to Login</a>`
        );
    }
  };

  static login_get = (req, res) => {
    res.render("login.ejs");
  };

  static g2_get = (req, res) => {
    res.render("g2_page.ejs");
  };

  static signup_get = (req, res) => {
    res.render("signup.ejs");
  };

  static signup_post = async (req, res) => {
    try {
      const data = req.body;

      // Validate required fields
      data.username = data.username ? data.username.trim() : "";
      if (!data.username || !data.password || !data.userType) {
        return res
          .status(400)
          .send("<h2>Username, password, and user type are required.</h2>");
      }

      // Check if the username already exists
      const existingUser = await User.findOne({ username: data.username });
      if (existingUser) {
        return res.status(400)
          .send(`<h2>Username already exists. Please choose another.</h2>
            <a href="/Login">Go back to Signup</a>`);
      }

      // Hash the password
      const hashed_pwd = await bcrypt.hash(data.password, 10);

      // Create a new user
      const user_to_save = new User({
        username: data.username,
        password: hashed_pwd,
        userType: data.userType,
      });

      // Save the user and respond
      await user_to_save.save();
      res.send(`<h2>You have successfully signed up!</h2>
        <a href="/Login">Go to Login</a>`);
    } catch (err) {
      console.error("Error saving user:", err);
      res.status(500).send(`<h2>Signup failed. Please try again later.</h2>
        <a href="/Login">Go back to Signup</a>`);
    }
  };
}

module.exports = Controller;
